import {get } from "request";

import axios from 'axios'
const instance = axios.create({
    baseURL: "http://127.0.0.1:5000",
    timeout: 5000000
});

export function myGet(url, params) {
    return instance.get(url, { params });
}

export function myPost(url, data) {
    return instance.post(url, data);
}