<template>
  <div style="height: 100%">
    <div id="chart" class="chart"></div>
  </div>
</template>
<script>
// 引入 ECharts 主模块
var echarts = require("echarts/lib/echarts");
// 引入柱状图
require("echarts/lib/chart/graph");
// 引入提示框和标题组件
require("echarts/lib/component/tooltip");
require("echarts/lib/component/title");
export default {
  name: "Charts",
  components: {},
  mixins: [],
  props: {
    chartList: {
      type: Array,
      required: true,
    },
    graphReset: {
      type: Boolean,
      required: true,
    },
  },
  watch: {
    chartList: {
      handler(val) {
        this.formatData(val || [], this.flush);
      },
      deep: true,
    },
    graphReset: {
      handler(val) {
        this.flush = val ? true : false;
      },
    },
  },
  data() {
    return {
      myChart: "",
      seriesData: [],
      seriesLinks: [],
      seriesId: [],
      allData: [],
      flush: false,
      lastClickId: "",
    };
  },
  computed: {},
  methods: {
    /**
     * 节点点击事件
     */
    async nodeClick(params) {
      const index = this.seriesData.findIndex(
        (item) => item.id === params.data.id
      );
      const info = this.seriesData[index];
      console.log(info)
      // 点击根节点返回主界面
      if (info.isRoot) {
        this.$emit("ref");
        // 清空 栈和保存的数据
        this.allData = [];
        this.seriesId = [];
        return;
      }
      // 清除该节点的所有子节点
      else if (info.isClicked) {
        console.log("回收子图");
        let popData = [];
        let popId = [];
        let deleteData = [];
        let deleteId = [];
        const nodeIndex = this.seriesId.findIndex((item) => item === info.id);
        while (this.seriesId.length - 1 > nodeIndex) {
          popId.push(this.seriesId.pop());
          popData.push(this.allData.pop());
        }
        deleteData.push(this.allData.pop());
        deleteId.push(this.seriesId.pop());
        while (popId.length > 0) {
          let theLastData = popData.pop();
          let theLastId = popId.pop();
          let theChildOfDeleted = false;
          deleteData.forEach((theDelete, index) => {
            theDelete[0].children.forEach((theDeleteChild, cIndex) => {
              if (theDeleteChild.id == theLastId) {
                theChildOfDeleted = true;
              }
            });
          });
          this.allData.forEach((theKeep, index) => {
            theKeep[0].children.forEach((theKeepChild, cIndex) => {
              if (theKeepChild.id == theLastId) {
                theChildOfDeleted = false;
              }
            });
          });
          if (theChildOfDeleted) {
            deleteData.push(theLastData);
            deleteId.push(theLastId);
          } else {
            this.allData.push(theLastData);
            this.seriesId.push(theLastId);
          }
        }
        console.log("删除节点");
        console.log(deleteId);
        // 重新渲染图
        this.formatData([]);
      } else {
        // 否则查询该节点的所有子节点
        this.$emit("search", info.name);
      }
    },
    /**
     * 设置echarts配置项,重绘画布
     */
    initCharts() {
      if (!this.myChart) {
        this.myChart = echarts.init(document.getElementById("chart"));
        this.myChart.on("click", (params) => {
          if (params.dataType === "node") {
            //判断点击的是图表的节点部分
            this.nodeClick(params);
          }
        });
      }

      // 指定图表的配置项和数据
      let option = {
        // 动画更新变化时间
        // animationDurationUpdate: 1500,
        // animationEasingUpdate: "quinticInOut",
        animation: false,
        tooltip: {
          show: true,
          trigger: "item",
          position: "right",
          backgroundColor: "rgba(0,0,0,0.6)",
          borderColor: "rgba(242, 128, 5, 1)",
          borderWidth: 2,
          paddding: 5,
          textStyle: {
            fontSize: 5,
            lineHeight: 20,
          },
          extraCssText: "text-align: left; border-style:dashed",
          formatter: function (param) {
            if (param.dataType === "node") {
              if (param.data.id < 0) {
                var htmlStr = `
                <div>
                  <ul style="
                  position:left; 
                  color:${param.color};
                  list-style-type:none;
    	            padding:0px;
    	            margin:0px;"
                  >
                    <li>信号频率: ${
                      param.data.attributes.Carrier_frequency
                    }</li>
                    <li>调制方式: ${
                      param.data.attributes.Modulation_method
                    }</li>
                    <li>信号功率: ${
                      parseFloat(param.data.attributes.Signal_power).toFixed(
                        1
                      ) + param.data.attributes.Signal_power.substr(-3, 3)
                    }
                    </li>
                    <li>信噪比: ${
                      param.data.attributes.Signal_to_noise_ratio
                    }</li>
                  </ul>
                </div>
                `;
              } else {
                var htmlStr = `
                <div>
                  <ul style="
                  position:left; 
                  color:${param.color};
                  list-style-type:none;
    	            padding:0px;
    	            margin:0px;"
                  >
                    <li>干扰带宽: ${
                      param.data.attributes.Interference_bandwidth
                    }</li>
                    <li>干扰频率: ${
                      param.data.attributes.Interference_frequency
                    }</li>
                    <li>干扰方式: ${param.data.attributes.Interference_method}
                    </li>
                    <li>干扰功率: ${
                      parseFloat(
                        param.data.attributes.Interference_power
                      ).toFixed(1) + "dBm"
                    }</li>
                  </ul>
                </div>
                `;
              }
              return htmlStr;
            }
          },
        },

        series: [
          {
            type: "graph",
            layout: "force",
            legendHoverLink: true, //是否启用图例 hover(悬停) 时的联动高亮。
            hoverAnimation: true, //是否开启鼠标悬停节点的显示动画
            edgeLabel: {
              position: "middle", //边上的文字样式
              normal: {
                formatter: function (params) {
                  //console.log(params);
                  return params.data.content;
                },
                show: true,
              },
            },
            edgeSymbol: ["arrow", ""],
            //cursor: "auto",
            force: {
              edgeLength: [100, 200],
              repulsion: 500,
              gravity: 0.1,
              layoutAnimation:true,
              //layoutAnimation: false,
            },
            roam: true,
            draggable: true, //每个节点的拖拉

            itemStyle: {
              normal: {
                color: function (params) {
                  return params.data.color;
                },
                // cursor: "pointer",
                //color:Math.floor(Math.random()*16777215).toString(16),
                // color: ['#fc853e','#28cad8','#9564bf','#bd407e','#28cad8','#fc853e','#e5a214'],
                label: {
                  //formatter: "{c}",为什么这个写上就不打开了？
                  show: true,
                  position: [-10, -15],
                  textStyle: {
                    //标签的字体样式
                    color: "#fff", //字体颜色
                    fontStyle: "normal", //文字字体的风格 'normal'标准 'italic'斜体 'oblique' 倾斜
                    fontWeight: "bolder", //'normal'标准'bold'粗的'bolder'更粗的'lighter'更细的或100 | 200 | 300 | 400...
                    fontFamily: "sans-serif", //文字的字体系列
                    fontSize: 12, //字体大小
                  },
                },
                nodeStyle: {
                  brushType: "both",
                  borderColor: "rgba(255,215,0,0.4)",
                  borderWidth: 1,
                },
              },
              //鼠标放上去有阴影效果
              emphasis: {
                shadowColor: "#00FAE1",
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 40,
              },
            },
            lineStyle: {
              width: 2,
            },
            label: {
              color: "#00FAE1",
              fontSize: 18,
            },
            symbolSize: 20, //节点大小
            links: this.seriesLinks,
            data: this.seriesData,
            cursor: "pointer",
          },
        ],
      };
      //console.log("option", option);
      // 使用刚指定的配置项和数据显示图表。
      this.myChart.setOption(option);
    },
    /**
     * 格式化数据到表格需要的数据
     */
    formatData(list, reset = false) {
      console.log("重新渲染图");
      let nodes = [];
      let childNodes = [];
      const data = [];
      const links = [];
      let target = "";
      this.seriesData = [];
      this.seriesLinks = [];
      if (reset) {
        this.allData = [];
        this.seriesId = [];
      }
      // 如果接收到数据不为空 说明有新的节点展开
      if (list.length > 0) {
        this.allData.push(list);
        // 以堆栈的方式保存历次点击的节点
        target = list[0].id + "";
        console.log(target)
        this.seriesId.push(target);
      }
      // 展示当前栈内存放的点击节点
      //console.log(this.seriesId);

      //构建网络所有节点和连边
      // 遍历所有父亲节点
      console.log("已展开节点");
      console.log(this.seriesId);
      this.allData.forEach((father, index) => {
        const fatherId = father[0].id + "";
        // 添加根节点
        if (index == 0) {
          const dataInfo = {
            id: fatherId,
            name: father[0].name,
            category: father[0].categary,
            isClicked: true,
            isRoot: true,
            symbolSize: 30,
            color: father[0].color,
            attributes: father[0].attributes,
          };
          data.push(dataInfo);
        }
        // 添加除根节点外的父亲节点
        else {
          // 如果这个父亲节点是其他节点的子节点
          if (this.isNodeRepetition(data, fatherId)) {
            // 将该节点由子节点升级为父亲节点
            // 即表示该节点已经展开
            let theIndex = data.findIndex((item) => item.id === fatherId);
            data[theIndex].isClicked = true;
            data[theIndex].symbolSize = 25;
          }
        }
        // 添加父亲节点的所有子节点
        childNodes = [].concat(father[0].children);
        childNodes.forEach((child, cIndex) => {
          const childId = child.id + "";
          // 如果子节点没有重复则添加
          if (!this.isNodeRepetition(data, childId)) {
            const childInfo = {
              id: childId,
              category: child.categary,
              name: child.name,
              isClicked: false,
              attributes: child.attributes,
              color: child.color,
            };
            data.push(childInfo);
          }
          // 添加节点之间的连边
          // 如果父亲节点的子节点是未展开的，即该子节点没有升级为父亲节点则添加连边
          const childIndataIndex = data.findIndex(
            (item) => item.id === childId
          );
          if (!data[childIndataIndex].isClicked) {
            // 信号与信号 干扰与干扰
            if (childId * fatherId > 0) {
              links.push({
                content: child.categary,
                value: 100,
                target: childId,
                source: fatherId,
                lineStyle: child.lineStyle,
                symbol: ["arrow", "arrow"],
              });
            } else {
              // 信号与干扰
              links.push({
                content: child.categary,
                value: 100,
                target: childId,
                source: fatherId,
                lineStyle: child.lineStyle,
              });
            }
          }
        });
      });
      // 更新图数据
      this.seriesData.push(...data);
      this.seriesLinks.push(...links);
      //console.log(this.seriesData);
      // 重新渲染画布
      this.initCharts();
    },
    /**
     * 点击节点折叠操作
     */
    removeChilds(id) {
      console.log("清除数据");
      // 清除data数据
      let list = [];
      let links = [];
      let delIds = [];
      this.getDeleteParentIds(delIds, [id]);

      this.seriesData.map((item) => {
        if (!delIds.includes(item.id)) {
          list.push(item);
        }
      });
      this.seriesLinks.map((item) => {
        if (!delIds.includes(item.source) && !delIds.includes(item.target)) {
          links.push(item);
        }
      });
      this.seriesData = [].concat(list);
      this.seriesLinks = [].concat(links);
      this.initCharts();
    },
    /**
     * 递归获取当前节点以下节点id
     */
    getDeleteParentIds(delIds, ids) {
      let list = [];
      this.seriesData.map((item) => {
        if (ids.includes(item.parentId)) {
          list.push(item.id);
        }
      });
      if (list.length > 0) {
        delIds.push(...list);
        this.getDeleteParentIds(delIds, list);
      }
    },
    // 判断节点是否重复
    isNodeRepetition(data, target) {
      let repetition = false;
      data.forEach((item, index) => {
        //console.log(item.id, target, item.id === target);
        if (item.id === target) {
          repetition = true;
        }
      });
      if (repetition) {
        return true;
      } else {
        return false;
      }
    },
  },
  created() {},
  mounted() {},
  beforeDestroy() {},
};
</script>
<style scoped>
.chart {
  height: 100%;
}
</style>