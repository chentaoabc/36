<template>
    
    <div>
  <div class="container" >
 
    <ul class="signal_label">

      <li @click="initTags()" style="color: yellow">全部信号</li>
      <li

        v-for="(value, i) in signalColor"
        :key="i"
        @click="sendLabel(value.label)"
        :style="{ color: value.color}"
  
      >
        {{ value["label"] }}   
      </li>
    </ul>
   
    <svg class="keywords" @mousemove="listener($event)" >
      <a
        href="javascript:void(0)"
        v-for="(tag, index) in tags"
        :key="index"
        @click="nodeClick(tag)"
      >
        <text
          class="text"
           :x="tag.x"
          :y="tag.y"
          :font-size="20 * (600 / (600 - tag.z))"
          :fill-opacity="(400 + tag.z) / 600"
          :fill="tag.color"
        >
          {{ tag.text }}
        </text>
      </a>
    </svg>

 </div>
    </div>
</template>
<script>
import { myGet, myPost } from "../utils/request";
import axios from 'axios';
//  import { search } from "./KnowledgeGraph";
export default {
  name: "Keywords",
  components: {},
  mixins: [],
  props: {},
  data() {
    return {
      name:"",
      signal:"",
      signal_bandwith:"",
      signal_power:"",
      signal_noise:"",
      signal_frequency:"",

      tags: [],
      RADIUS: 200,
      ZRADIUS: 200,
      CX: 720,
      CY: 300,
      speedX: Math.PI / 360,
      speedY: Math.PI / 360,
      signalName: null,
      signalColor: null,
      helloWorld: null,
              form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        }
    };
  },

  computed: {},
  methods: {

    
    /**
     * 标签点击
     */
    async nodeClick(tag) {
      this.$emit("searchData", tag.text);
    },
    
    /**
     * 切换信号或干扰种类
     */
    // changeClassificaton(label) {
    //   //const tagNames = [...signal_category[label]];
    //   //console.log(getData);
    //   let tagNames;
    //   if (label.substring(0, 2) == "信号") {
    //     tagNames = [...signal_category[label]];
    //   } else {
    //     tagNames = [...noise_category[label]];
    //   }

    //   //初始化标签位置
    //   let tags = [];
    //   const length = tagNames.length;
    //   for (let i = 0; i < length; i++) {
    //     let tag = {};
    //     let k = -1 + (2 * (i + 1) - 1) / length;
    //     let a = Math.acos(k);
    //     let b = a * Math.sqrt(length * Math.PI);
    //     tag.text = tagNames[i];
    //     tag.x = this.CX + this.RADIUS * Math.sin(a) * Math.cos(b);
    //     tag.y = this.CY + this.RADIUS * Math.sin(a) * Math.sin(b);
    //     tag.z = this.ZRADIUS * Math.cos(a);
    //     tag.color =
    //       "rgb(" +
    //       parseInt(Math.random() * 255) +
    //       "," +
    //       parseInt(Math.random() * 255) +
    //       "," +
    //       parseInt(Math.random() * 255) +
    //       ")";
    //     tags.push(tag);
    //   }
    //   this.tags = [].concat(tags);
    // },


    //调用数据库切换标签
    getNodeName(tagNames) {
      //初始化标签位置
      let tags = [];
      const length = tagNames.length;
      for (let i = 0; i < length; i++) {
        let tag = {};
        let k = -1 + (2 * (i + 1) - 1) / length;
        let a = Math.acos(k);
        let b = a * Math.sqrt(length * Math.PI);
        tag.text = tagNames[i];
        tag.x = this.CX + this.RADIUS * Math.sin(a) * Math.cos(b);
        tag.y = this.CY + this.RADIUS * Math.sin(a) * Math.sin(b);
        tag.z = this.ZRADIUS * Math.cos(a);
        tag.color =
          "rgb(" +
          parseInt(Math.random() * 255) +
          "," +
          parseInt(Math.random() * 255) +
          "," +
          parseInt(Math.random() * 255) +
          ")";
        tags.push(tag);
      }
      this.tags = [].concat(tags);
    },
    /**
     * 初始化标签数据
     */
    initTags() {
      const tagNames = this.signalName;
      //const tagNames = [...categarys];
      //console.log(tagNames);
      //console.log(this.signalName.);
      //初始化标签位置
      let tags = [];
      const length = tagNames.length;
      for (let i = 0; i < length; i++) {
        let tag = {};
        let k = -1 + (2 * (i + 1) - 1) / length;
        let a = Math.acos(k);
        let b = a * Math.sqrt(length * Math.PI);
        tag.text = tagNames[i];
        tag.x = this.CX + this.RADIUS * Math.sin(a) * Math.cos(b);
        tag.y = this.CY + this.RADIUS * Math.sin(a) * Math.sin(b);
        tag.z = this.ZRADIUS * Math.cos(a);
        tag.color =
          "rgb(" +
          parseInt(Math.random() * 255) +
          "," +
          parseInt(Math.random() * 255) +
          "," +
          parseInt(Math.random() * 255) +
          ")";
        tags.push(tag);
      }
      this.tags = [].concat(tags);
    },
    /**
     * 自动滚动效果,计算滚动位置
     */
    rotateX(speedX) {
      var cos = Math.cos(speedX);
      var sin = Math.sin(speedX);
      for (let tag of this.tags) {
        var y1 = (tag.y - this.CY) * cos - tag.z * sin + this.CY;
        var z1 = tag.z * cos + (tag.y - this.CY) * sin;
        tag.y = y1;
        tag.z = z1;
      }
    },
    /**
     * 自动滚动效果,计算滚动位置
     */
    rotateY(speedY) {
      var cos = Math.cos(speedY);
      var sin = Math.sin(speedY);
      for (let tag of this.tags) {
        var x1 = (tag.x - this.CX) * cos - tag.z * sin + this.CX;
        var z1 = tag.z * cos + (tag.x - this.CX) * sin;
        tag.x = x1;
        tag.z = z1;
      }
    },
    /**
     * 响应鼠标移动
     */
    listener(event) {
      //
      var x = event.clientX - this.CX;
      var y = event.clientY - this.CY;
      this.speedX =
        x * 0.0001 > 0
          ? Math.min(this.RADIUS * 0.00002, x * 0.0001)
          : Math.max(-this.RADIUS * 0.00002, x * 0.0001);
      this.speedY =
        y * 0.0001 > 0
          ? Math.min(this.RADIUS * 0.00002, y * 0.0001)
          : Math.max(-this.RADIUS * 0.00002, y * 0.0001);
    },
    /**
     * 监听窗体大小变化
     */
    resizeWindow() {
      let height = document.body.clientHeight;
      let width = document.body.clientWidth;
      width = width * 0.85;
      if (width > 1200) {
        this.CX = width / 2;
      }
      height = height - 150;
      this.CY = height / 2;
      let radius = Math.min(this.CY, this.CX) / 2;
      if (radius > 200) {
        this.RADIUS = radius;
      }
      this.initTags();
      this.$emit("windowResize");
    },
    
    // init() {
    //   Promise.all([this.initLabel]).then((res) => {
    //     console.log(res.data);
    //     this.initTags();
    //     this.resizeWindow();
    //     window.addEventListener("resize", this.resizeWindow);
    //   });
    // },
    /**
     * 与后端交互
     */

    getHandle() {
      myGet("/", {}).then((res) => {4
        console.log(res);
        this.helloWorld = res;
      });
    },
    async initLabel() {
      await myGet("/init").then((res) => {
        //console.log(res.data);
        //this.signalName = JSON.parse(JSON.stringify(res.data["signalName"]));
        this.signalName = res.data["signalName"];
        this.signalColor = res.data["signalColor"];
        console.log(res.data);
        console.log(this.signalName);
        console.log(this.signalColor);
      });
      this.initTags();
      this.resizeWindow();
      window.addEventListener("resize", this.resizeWindow);
    },
    // 获取对应label的所有节点
    sendLabel(labelName) {
      myGet("/node_label", {
        label: labelName,
      }).then((res) => {
        console.log(res.data);
        this.getNodeName(res.data);
      });
    },
    //测试用
    postHandle() {
      myPost("/post_test", {
        hello: "world",
      }).then((res) => {
        console.log(res);
      });
    },
  },
  created() {},
  mounted() {
    //this.init();
    this.initLabel();
    //this.initTags();
    // this.resizeWindow();
    // window.addEventListener("resize", this.resizeWindow);

    //使球开始旋转
    const interval = setInterval(() => {
      this.rotateX(this.speedX);
      this.rotateY(this.speedY);
    }, 17);
    this.$once("hook:beforedestroy", () => {
      interval && clearInterval(interval);
      window.removeEventListener("resize", this.resizeWindow);
    });
  },
  beforeDestroy() {},
};
</script>
<style scoped>
.container{  width: 100%;
  height: 100%;
   z-index: 11;
}

.keywords{
    /* width: 1100px; */
    width: 1000px;
    height: 1000px; 
    left:-90px ;
    top: 50px;  
    position: absolute;
    z-index: 15;

  
}


.keywords.text:hover {
  font-size: 200%;
}

/* .text{} */



.signal_label {
  position: absolute;
  left: 10px;
  top: 150px;
  margin: 0 auto;
  text-align: left;
  cursor: pointer;
  margin-top: 10x;
  line-height: 50px;
  z-index:10;
}


/* .noise_label {
  position: absolute;
  left: 150px;
  top: 10px;
  margin: 0 auto;
  text-align: left;
  cursor: pointer;
} */

/* .label_test {
  position: absolute;
  left: 150px;
  top: 150px;
  margin: 0 auto;
  text-align: left;
  cursor: pointer;
  
} */

/* 设置信号输入框样式 */
/* .add{
    position: absolute;
    right: 0px;
      top: 80px;
  margin: 0 auto;
  text-align: center;

} */


</style>