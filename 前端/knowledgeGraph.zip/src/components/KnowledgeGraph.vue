<template>
<div>
  <div class="container">
    <div class="center">
      <div class="header">
        <input
          type="text"
          class="ipt"
          v-model="searchContent"
          @keydown.enter="search(searchContent,true)"
          placeholder="搜索信号1试试"
          v-loading.fullscreen.lock="fullscreenLoading"
        />
        <p class="tips">
          <span>搜索示例:信号1</span>
        </p>

      </div>
      
      <!-- <div class="add">

        <el-tooltip :content="'关系推理显示: ' + value5" placement="top" >
          <el-switch v-model="value5" active-color="#13ce66" inactive-color="#ccc" active-value="true" inactive-value="false" @change="change">
          </el-switch>
        </el-tooltip>

      </div> -->
    <div class="add1"    z-index=10>
      <el-tooltip :content="'关系推理显示: ' + value5" placement="top" >
          <el-switch v-model="value5" active-color="#13ce66" inactive-color="#ccc" active-value="true" inactive-value="false" @change="change">
          </el-switch>
      </el-tooltip>

        <el-form ref="form" :model="form" label-width="100px" v-show="isShow"  z-index= 10;>
          <el-form-item label="信号名称">
          <el-input v-model="name"  v-show="isShow" placeholder="请输入信号名称" class="in"></el-input>
        </el-form-item>

        <el-form-item label="调制方式" >
          <el-select v-model="signal" placeholder="请选择调制方式">
            <el-option label="16QAM" value="signal_way1"></el-option>
            <el-option label="32QAM" value="signal_way2"></el-option>
            <el-option label="64QAM" value="signal_way3"></el-option>
          </el-select>
        </el-form-item>

          <el-form-item label="信号带宽(KHz)">
        <el-input v-model="signal_bandwith" oninput ="value=value.replace(/[^0-9.]/g,'')" maxLength='9' placeholder="请输入信号带宽"></el-input>
          </el-form-item>

          <el-form-item label="载波频率(MHz)">
        <el-input v-model="signal_frequency"  oninput ="value=value.replace(/[^0-9.]/g,'')" maxLength='9' placeholder="请输入载波频率"></el-input>
          </el-form-item>

        <el-form-item label="信号功率(dBm)">
      <el-input v-model="signal_power" oninput ="value=value.replace(/[^0-9.]/g,'')" maxLength='9' placeholder="请输入信号功率"></el-input>
        </el-form-item>

        <el-form-item label="信噪比(dB)">
      <el-input v-model="signal_noise" oninput ="value=value.replace(/[^0-9.]/g,'')" maxLength='9' placeholder="请输入信噪比"></el-input>
        </el-form-item>

        <el-form-item>
      <el-button type="primary" @click="onSubmit"  >关系推理</el-button>
      </el-form-item>



    </el-form>
    
    
      </div>


      <div class="canvas"  z-index=10;>
        <Keywords
          v-show="type === 1"
          @searchData="search"
          @windowResize="windowResize"
        ></Keywords>
        
        <Charts
          ref="charts"
          v-show="type === 2"
          :chartList="searchList"
          :graphReset="searchByUser"
          @ref="type = 1"
          @search="search"
        />
      </div>
    </div>

  </div>
  
 </div>
</template>
<script>
import Keywords from "./Keywords";
import Charts from "./Charts";
import { myGet, myPost } from "../utils/request";
import { showLoading, hideLoading } from './loading';
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import axios from 'axios';

export default {
  name: "KnowledgeGraph",
  components: {
    Keywords,
    Charts,
  },
  mixins: [],
  props: {},
  data() {
    return {
       num: 0,
      count:"",
       name:"",
      signal:"",
      signal_bandwith:"",
      signal_power:"",
      signal_noise:"",
      signal_frequency:"",
      value5: 'true',
       isShow : true,
      fullscreenLoading: false,
      searchContent: "",
      type: 1,
      searchList: [],
      searchByUser: false,
      showData: null,
      js:"",
      find:"",
 form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },


    };
  },
  computed: {},
  created() {},

  methods: {
     
      
    /**
     * 搜索方法,text为空为点击类别操作,不为空则为输入框搜索
     */
    // 异步函数
    // async search(text) {
    //   console.log(text);
    //   this.searchContent = text;
    //   if (!text) {
    //     this.type = 1;
    //     return;
    //   }
    //   try {
    //     let result = await search(text);
    //     console.log(result);
    //     this.type = 2;
    //     this.searchList = [].concat(result);
    //   } catch (error) {
    //     alert("未查询到数据,请更改查询条件");
    //   }
    // },


//设置关系推理搜索框显示和隐藏
           change(data){
          if(data == "false" ||this.searchContent!=''){
            console.log(data)
            console.log(this.value5)
            console.log(this.searchContent)
            this.isShow = false;
        }else{
            this.isShow = true;
        }
      },


   // 把输入框输入传给后台
     async  onSubmit(){
       myPost("/add", {
          信号名称:this.name,
          调制方式:this.signal,
          信号带宽:this.signal_bandwith,
          载波频率:this.signal_frequency,
          信号功率:this.signal_power,
          信噪比:this.signal_noise,
      }).then((res) => {
      this.forget()
      })
        .catch(function (error) {
                console.log(error);
                alert("名字已经存在,请重新输入")
        });     
    },


    forget(){
           myGet("/check").then((res) => {
        // console.log(res);
           let timer
        let result = res.data;
        console.log(result);
        if (result != "0") {
          console.log(result)
            if (result == "1") {
            this.search(this.name),
          // alert("信号节点已经创建")
          console.log("信号节点已经创建");
           } else if(result == "2") {
          this.search(this.name),
          // alert("信号相似度关系已经创建")
          console.log("信号相似度关系已经创建");
           }else if (result == "3"){
            this.search(this.name),
           alert("推理完成")
           console.log("信号误码率已经创建");
           }
           else if (result == "5"){
          alert("名字已经存在,请重新输入")
           }
          timer=setTimeout(() => {
          this.forget()
           }, 2000);

        } else {
           console.log("查询没有开始")
          // alert("未查询到数据,请更改查询条件");
         clearTimeout(timer);
        //  if (result=="3"){
        //  alert("推理完成")
        //  }else if (result=="5"){
        //    alert("名字已经存在")
        //  }
        }
      });
    },


// 可以实现轮询的
    //         forget(){
    //    myGet("/check").then((res) => {
    //     // console.log(res);
    //     let result = res.data;
    //     console.log(result);
    //   if (result == "1") {
    //       this.search(this.name),
    //       // alert("信号节点已经创建")
    //       console.log("信号节点已经创建");
    //     } else if(result == "2") {
    //       this.search(this.name),
    //       // alert("信号相似度关系已经创建")
    //       console.log("信号相似度关系已经创建");
    //     }else if (result == "3"){
    //       this.search(this.name),
    //       // alert("推理完成")
    //       console.log("信号误码率已经创建");
    //     }
    //   });
    //     find=setTimeout(() => {
    //       this.forget()
    //   }, 2000);
    
    // },



    setTimer () {
         let timer
        axios.post(url, params)
        .then(function (res) {
            if(res){
                console.log(res);
                timer = setTimeout(() => {
                    this.setTimer()
                }, 5000)       
            }else {
                clearTimeout(timer) //清理定时任务
            }
            
        })
        .catch(function (error) {
                console.log(error);
        });
},        




    async search(text, userInput = false) {
      // 添加加载图形
      showLoading()

      // 关系推理隐藏
      this.value5=false;
      this.isShow=false;
        
      console.log(this.value5)
      if (!text) {
        this.type = 1;
        return;
      }
      this.searchByUser = userInput ? true : false;
      this.getChild(text);
    },

    getChild(text) {
      myGet("/child", {
        name: text,
      }).then((res) => {
        // console.log(res);
        let result = res.data;
        
        // 关闭加载图形
        hideLoading()
        // console.log(result);
        if (result == "0") {
          alert("未查询到数据,请更改查询条件");
        } else {
          this.type = 2;
          this.searchList = [].concat(result);
        }
      });
    },
    /**
     * 窗体大小变化回调
     */
    windowResize() {
      const charts = this.$refs.charts;
      charts && charts.myChart && charts.myChart.resize();
    },
  },
  created() {},
  mounted() {
    this.type = 1;
  },
  beforeDestroy() {},
};
</script>
<style scoped>

/* .container {
  overflow: hidden;
  position: relative;
  min-height: 100vh;
} */
.canvas {
  margin-top: 0px;

  height: calc(100vh - 1px);
}
.center {
  position: relative;
  min-width: 1200px;
  margin: 0 auto;
  width: 90%;
}
.header {
  padding-top: 30px;
  left: -50px;
  position: relative;
  
}
.ipt {
  border: 1px solid #9093c7;
  border-radius: 20px;
  width: 374px;
  height: 44px;
  line-height: 44px;
  box-sizing: border-box;
  color: #555;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  
}

.tips {
  font-size: 14px;
  color: #ccc;
  line-height: 17px;
  margin-top: 10px;

}

/* 设置信号输入框样式 */

.add1{
    position: absolute;
    right: 5px;
      top: 120px;
  margin: 0 auto;
  text-align: center;
}



/* 调整控制关系推理的开关按钮布局 */
.el-tooltip{
  top: -30px;
  /* right:-700px; */
  float:right;

}

.el-tooltip>>>.el-switch__core{
  top:10px;
 
}


.el-form-item{   
      margin-bottom: 50px; 
      
    }

.el-form-item>>>.el-input{
    width: 320px;
  }
.el-form-item>>>.el-form-item__label{
    line-height: 40px;
    font-size: 16px;
    color:skyblue
  }
.el-form-item>>>.el-input__inner{   
    background:#fff;   
    height: 45px;   
    border-radius: 16px;    
}

  .el-form-item>>>.el-select {
    width: 320px;
}



</style>

